# Migrate to version 1.1.4 of LumApps Playground

We provide 2 shell scripts to migrate your extension to make them compatible with the latest build process using webpack

2 scripts are available :
1. To migrate a single extension
2. To migrate a entire folder containing multiple extensions
   
Example
```
my-extensions
    + my-first-extension
    + my-second-extension
    + nested-extensions
        +my-third-extension

```

### 1. Migrate a single extension
You have to use the `migration.sh` script in the root folder of the extension (same level than your `package.json` file).

And then you can run the script
```shell
$> ./migration.sh
```

_Note: You may need to edit the permission to execute the script_
```shell
$> chmod 755 migration.sh
```

### 2. Migrate multiple extensions
You have to use the `migration_folder.sh` script in the root folder containing your extensions.

```
my-extensions
    + my-first-extension
    + my-second-extension
    + nested-extensions
        +my-third-extension
    | migration_folder.sh

```

And then you can run the script
```shell
$> ./migration_folder.sh
```

_Note: You may need to edit the permission to execute the script_
```shell
$> chmod 755 migration_folder.sh
```

### Check the migration

To ensure the migration is completly done you can check the following points :

 - Check the presence of a `tsconfig.build.json` file in the extension folder (at root level)
 - check the export of you component in the `index.XX.ts` files, you do not have default export anymore (but something like `export { Widget };`)
 - in your `package.json` you should have `reselect` dependenecy and `ts-loader` dependency (`ts-loader` in devDependencies)

