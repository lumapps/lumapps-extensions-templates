#!/bin/bash

#COLORS
BLUE='\033[0;34m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No 

#Configuration file for TS
TSCONFIG_FILE=./tsconfig.build.json

# Index file that export component
INDEX_CONTENT=./src/index.content.ts
INDEX_SETTINGS=./src/index.settings.ts
INDEX_GLOBAL_SETTINGS=./src/index.global_settings.ts
INDEX_WIDGET=./src/index.widget.ts
INDEX_NO_GLOBAL_SETTINGS=./src/index.widget.no_global.ts

echo -e "${BLUE}*******************************************${NC}"
echo -e "${BLUE}*** Migration script for your extension ***${NC}"
echo -e "${BLUE}*******************************************${NC}"

PS3="Choose between yarn or npm to add new dependencies: "
select tool in yarn npm
do
    echo $tool
    break
done


migrate_extension() {
    # Creation of tsconfg File#!/bin/bash
    echo -e "${BLUE}1. Creation of tsconfig.build.json file${NC}"
    echo
    if test -f "$TSCONFIG_FILE"; then
        echo -e "   ${GREEN}tsconfig.build.json already exist${NC}"
    else
        echo '
        {
            "compilerOptions": {
                "target": "es5",
                "lib": [
                "dom",
                "dom.iterable",
                "esnext"
                ],
                "allowJs": true,
                "skipLibCheck": true,
                "esModuleInterop": true,
                "allowSyntheticDefaultImports": true,
                "strict": true,
                "forceConsistentCasingInFileNames": true,
                "noFallthroughCasesInSwitch": true,
                "module": "ESNext",
                "moduleResolution": "node",
                "resolveJsonModule": true,
                "isolatedModules": true,
                "noEmit": false,
                "jsx": "react-jsx"
            }
        }' > $TSCONFIG_FILE
        echo -e "   ${GREEN}File created${NC}"
    fi

    echo
    echo
    # Migration of export
    echo -e "${BLUE}2. Migrate default export to named export${NC}"
    echo
    if test -e "$INDEX_CONTENT"; then
        echo -e "  ${GREEN}"$INDEX_CONTENT
        sed -i -e "s/export default/export/g" $INDEX_CONTENT
    fi
    if test -e "$INDEX_SETTINGS"; then
        echo -e "  ${GREEN}"$INDEX_SETTINGS
        sed -i -e "s/export default/export/g" $INDEX_SETTINGS
    fi
    if test -e "$INDEX_GLOBAL_SETTINGS"; then
        echo -e "  ${GREEN}"$INDEX_GLOBAL_SETTINGS
        sed -i -e "s/export default/export/g" $INDEX_GLOBAL_SETTINGS
    fi
    if test -e "$INDEX_WIDGET"; then
        echo -e "  ${GREEN}"$INDEX_WIDGET
        sed -i -e "s/export default/export/g" $INDEX_WIDGET
    fi
    if test -e "$INDEX_NO_GLOBAL_SETTINGS"; then
        echo -e "  ${GREEN}"$INDEX_NO_GLOBAL_SETTINGS
        sed -i -e "s/export default/export/g" $INDEX_NO_GLOBAL_SETTINGS
    fi

    echo
    echo
    # Missing deps
    echo -e "${BLUE}3. Add missing dependencies${NC}"
    echo
    if [ $tool == 'yarn' ]; then
        echo "  Install tsloader@8.1.0"
        yarn add -D ts-loader@8.1.0
        echo "  Install reselect@4.0.0"
        yarn add reselect@4.0.0
    else
        echo "  Install tsloader@8.1.0"
        npm install --save-dev ts-loader@8.1.0
        echo "  Install reselect@4.0.0"
        npm install reselect@4.0.0
    fi    
}

for f in *; do
    if [ -d "$f" ]; then
        echo
        echo
        echo -e "-${BLUE}Folder : \e[1m"$f
        if [ "$f" != "node_modules" ]; then
            cd $f

            if test -e "package.json"; then
                migrate_extension
            else
                for ff in *; do
                    if [ -d "$ff" ]; then
                        cd $ff
                        echo -e "   -${BLUE}Folder : \e[1m"$ff
                        if test -e "package.json"; then
                            migrate_extension
                        fi
                        cd ..       
                    fi
                done
            fi
            cd ..
        fi
    fi
done

echo
echo -e "${GREEN}Migration script complete${NC}"