# Migrate to version 1.4.0 of LumApps Playground

We provide 2 shell scripts to migrate your extension to make them compatible with the latest version of the Playground

2 scripts are available :
1. To migrate a single extension
2. To migrate an entire folder containing multiple extensions
   
Example
```
my-extensions
    + my-first-extension
    + my-second-extension
    + nested-extensions
        +my-third-extension

```

### 1. Migrate a single extension
You have to use the `migration.sh` script in the root folder of the extension (same level than your `package.json` file).

And then you can run the script
```shell
$> ./migration.sh
```

_Note: You may need to edit the permission to execute the script_
```shell
$> chmod 755 migration.sh
```

### 2. Migrate multiple extensions
You have to use the `migration_folder.sh` script in the root folder containing your extensions.

```
my-extensions
    + my-first-extension
    + my-second-extension
    + nested-extensions
        +my-third-extension
    | migration_folder.sh

```

And then you can run the script
```shell
$> ./migration_folder.sh
```

_Note: You may need to edit the permission to execute the script_
```shell
$> chmod 755 migration_folder.sh
```

### Check the migration

To ensure the migration is completely done you can check the following points :

 - Check the `src/index.tsx` file:
   - You must not have any reference to "@lumapps-extensions-playground/devenv/devenv.esm.css" anymore
