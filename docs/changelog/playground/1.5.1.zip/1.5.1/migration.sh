#!/bin/bash

#COLORS
BLUE='\033[0;34m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Index file that export component
INDEX=./src/index.tsx
WIDGET_SETTINGS=./src/widget/WidgetSettings.tsx
WIDGET_GLOBAL_SETTINGS=./src/widget/WidgetGlobalSettings.tsx
SHARE_GLOBAL_SETTINGS=./src/extension/ShareGlobalSettings.tsx

echo -e "${BLUE}*******************************************${NC}"
echo -e "${BLUE}*** Migration script for your extension ***${NC}"
echo -e "${BLUE}*******************************************${NC}"

# Migration of props
echo -e "${BLUE}1. Add config typing${NC}"
echo
sed -i -e "s+config={config}+config={config as import('lumapps-sdk-js').ExtensionConfig}+g" $INDEX
echo
# Change widgets typing
if test -e $WIDGET_SETTINGS; then
    echo -e "${BLUE}1. Add typing to widget settings${NC}"
    echo
    sed -i -e "s+const WidgetSettings+const WidgetSettings: import('lumapps-sdk-js').SettingsComponent<any, any>+g" $WIDGET_SETTINGS
    echo
fi
if test -e $WIDGET_GLOBAL_SETTINGS; then
    echo -e "${BLUE}1. Add typing to widget global settings${NC}"
    echo
    sed -i -e "s+const WidgetGlobalSettings+const WidgetGlobalSettings: import('lumapps-sdk-js').GlobalSettingsComponent<any>+g" $WIDGET_GLOBAL_SETTINGS
    echo
    echo -e "${GREEN}Migration script complete${NC}"
fi
if test -e $SHARE_GLOBAL_SETTINGS; then
    echo -e "${BLUE}1. Add typing to share global settings${NC}"
    echo
    sed -i -e "s+const ShareGlobalSettings+const ShareGlobalSettings: import('lumapps-sdk-js').GlobalSettingsComponent<any>+g" $SHARE_GLOBAL_SETTINGS
    echo
    echo -e "${GREEN}Migration script complete${NC}"
fi
