# Migrate to use shipping-server in LumApps Playground

We provide 2 shell scripts to migrate your extension to use the playground version 1.5.1

2 scripts are available :

1. To migrate a single extension
2. To migrate a entire folder containing multiple extensions

Example

```
my-extensions
    + my-first-extension
    + my-second-extension
    + nested-extensions
        +my-third-extension

```

### 1. Migrate a single extension

You have to use the `migration.sh` script in the root folder of the extension (same level than your `package.json` file).

And then you can run the script

```shell
$> ./migration.sh
```

_Note: You may need to edit the permission to execute the script_

```shell
$> chmod 755 migration.sh
```

### 2. Migrate multiple extensions

You have to use the `migration_folder.sh` script in the root folder containing your extensions.

```
my-extensions
    + my-first-extension
    + my-second-extension
    + nested-extensions
        +my-third-extension
    | migration_folder.sh

```

And then you can run the script

```shell
$> ./migration_folder.sh
```

_Note: You may need to edit the permission to execute the script_

```shell
$> chmod 755 migration_folder.sh
```

### Check the migration

To ensure the migration is completely done you can check the following points :

-   Check that the `index.tsx` of your extension use the config props of the playground with the `as import('lumapps-sdk-js').ExtensionConfig` as type.
-   If you are base on a widget template :
    -   Check that your `WidgetSettings` use `: import('lumapps-sdk-js').SettingsComponent<any, any>` as type.
    -   Check that your `WidgetGlobalSettings` use `: import('lumapps-sdk-js').GlobalSettingsComponent<any, any>` as type.
-   If you are base on a share template :
    -   Check that your `ShareGlobalSettings` use `: import('lumapps-sdk-js').GlobalSettingsComponent<any, any>` as type.
