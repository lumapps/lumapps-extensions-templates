#!/bin/bash

#COLORS
BLUE='\033[0;34m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No 

# Index file that export component
INDEX=./src/index.tsx

echo -e "${BLUE}*******************************************${NC}"
echo -e "${BLUE}*** Migration script for your extension ***${NC}"
echo -e "${BLUE}*******************************************${NC}"

migrate_extension() {
    # Creation of tsconfg File#!/bin/bash
    echo -e "${BLUE}1. Migrate props injected to Playground${NC}"
    echo
    sed -i -e "s/Widget={/ContentComponent={/g" $INDEX
    sed -i -e "s/WidgetSettings={/SettingsComponent={/g" $INDEX
    sed -i -e "s/WidgetGlobalSettings={/GlobalSettingsComponent={/g" $INDEX
}

for f in *; do
    if [ -d "$f" ]; then
        echo
        echo
        echo -e "-${BLUE}Folder : \e[1m"$f
        if [ "$f" != "node_modules" ]; then
            cd $f

            if test -e "package.json"; then
                migrate_extension
            else
                for ff in *; do
                    if [ -d "$ff" ]; then
                        cd $ff
                        echo -e "   -${BLUE}Folder : \e[1m"$ff
                        if test -e "package.json"; then
                            migrate_extension
                        fi
                        cd ..       
                    fi
                done
            fi
            cd ..
        fi
    fi
done

echo
echo -e "${GREEN}Migration script complete${NC}"