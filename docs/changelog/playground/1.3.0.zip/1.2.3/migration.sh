#!/bin/bash

#COLORS
BLUE='\033[0;34m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Index file that export component
INDEX=./src/index.tsx

echo -e "${BLUE}*******************************************${NC}"
echo -e "${BLUE}*** Migration script for your extension ***${NC}"
echo -e "${BLUE}*******************************************${NC}"

# Migration of props
echo -e "${BLUE}1. Migrate props injected to Playground${NC}"
echo
sed -i -e "s/Widget={/ContentComponent={/g" $INDEX
sed -i -e "s/WidgetSettings={/SettingsComponent={/g" $INDEX
sed -i -e "s/WidgetGlobalSettings={/GlobalSettingsComponent={/g" $INDEX
echo
echo -e "${GREEN}Migration script complete${NC}"
