#!/bin/bash

#COLORS
BLUE='\033[0;34m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# playground-server folder
PLAYGROUND_SERVER_FOLDER=./playground-server

# package.json
PACKAGE_JSON=./package.json

echo -e "${BLUE}*******************************************${NC}"
echo -e "${BLUE}*** Migration script for your extension ***${NC}"
echo -e "${BLUE}*******************************************${NC}"

# Remove playground-server folder
echo -e "${BLUE}1. Remove playground-server folder${NC}"
echo
if [ ! -d "$PLAYGROUND_SERVER_FOLDER" ]; then
    echo -e "   ${GREEN}Playground folder already removed${NC}"
else
    rm -rf $PLAYGROUND_SERVER_FOLDER
    echo -e "   ${GREEN}Playground folder removed${NC}"
fi

echo
echo

# # Missing deps
echo -e "${BLUE}2. Replace playground-server by shipping-server package${NC}"
echo
PS3="Choose between yarn or npm to add new dependencies: "
select tool in yarn npm; do
    echo $tool
    case $tool in
    npm)
        echo "  Remove @lumapps-extensions-playground/playground-server"
        npm uninstall @lumapps-extensions-playground/playground-server
        echo "  Install @lumapps-extensions/shipping-server": "^1.1.2"
        npm install --save-dev @lumapps-extensions/shipping-server@^1.1.2
        ;;
    yarn)
        echo "  Remove @lumapps-extensions-playground/playground-server"
        yarn remove @lumapps-extensions-playground/playground-server
        echo "  Install @lumapps-extensions/shipping-server": "^1.1.2"
        yarn add -D @lumapps-extensions/shipping-server@^1.1.2
        ;;
    esac
    break
done
echo
echo

# Update package.json
echo -e "${BLUE}3. Update package.json commands${NC}"
echo
if test -e "$PACKAGE_JSON"; then
    echo -e "  ${GREEN}Update start command${NC}"
    sed -i -e "s+start:playground-server+start:shipping-server+g" $PACKAGE_JSON
    sed -i -e "s+node playground-server/index.js+lumapps-shipping-server+g" $PACKAGE_JSON
fi

echo
echo
echo -e "${GREEN}Migration script complete${NC}"
